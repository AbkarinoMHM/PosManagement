package com.ebe;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PosManagementBootApplication {

	public static void main(String[] args) {
		SpringApplication.run(PosManagementBootApplication.class, args);
	}
}
