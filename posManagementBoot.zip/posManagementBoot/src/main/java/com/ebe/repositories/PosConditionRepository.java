package com.ebe.repositories;

import com.ebe.entities.PosConditionEntity;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * Created by saado on 10/27/2016.
 */
public interface PosConditionRepository extends JpaRepository<PosConditionEntity, Integer> {
}
