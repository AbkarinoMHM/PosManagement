// Application module
angular.module('crudApp', ['ngMaterial'])
    .controller("regionController", regionController);

//Controller main
function regionController($scope, $http, $mdDialog) {

    // Function to get regions from the database
    getInfo();
    function getInfo() {
        // Sending request to region get service
        $http.get('../../services/region').success(function (data) {
            // Stored the returned data into scope
            $scope.details = data;
        });
    }

    // Enabling show_form variable to enable Add region button
    $scope.show_form = true;

    //Show add form
    $scope.showAddForm = function (event) {
        $scope.regionInfo = {};
        $mdDialog.show({
            clickOutsideToClose: true,
            scope: $scope,
            preserveScope: true,
            templateUrl: '../region/templates/addForm.html',
            parent: angular.element(document.body),
            targetEvent: event,
            controller: regionController
        });
    };

    //Show edit form
    $scope.currentRegion = {};
    $scope.showEditForm = function ($info) {
        $scope.currentRegion = $info;
        $mdDialog.show({
            clickOutsideToClose: true,
            scope: $scope,
            preserveScope: true,
            templateUrl: '../region/templates/editForm.html',
            parent: angular.element(document.body),
            targetEvent: $info,
            locals: {
                currentRegion: $scope.currentRegion
            },
            controller: regionController
        });
    };

    $scope.deleteInfo = function (info) {
        //show confirmatin dialog
        var confirm = $mdDialog.confirm()
            .title('Are you sure to delete this record?')
            .textContent('Record will be deleted permanently.')
            .ariaLabel('Delete Region')
            .targetEvent(event)
            .ok('Yes')
            .cancel('No');
        $mdDialog.show(confirm).then(function () {
            $http.delete('../../services/region/' + info.regionId).success(function (data) {
                getInfo();
            });
        }, function () {
            //delete cancelled
        });
    }


    $scope.editInfo = function (info) {
        $scope.currentRegion = info;
        $('#addRegionForm').slideUp();
        $('#editForm').slideToggle();
    }

    $scope.UpdateInfo = function (info) {
        $http.put('../../services/region/' + info.regionId, {
            "regionName": info.regionName
        }).success(function (data) {
            $scope.show_form = true;
            getInfo();
        });
    }

    //Dialog functions
    $scope.updateMsg = function (regionID) {
        $('#editForm').css('display', 'none');
    }

    $scope.hide = function () {
        $mdDialog.hide();
    };

    $scope.cancel = function () {
        $mdDialog.cancel();
    };

    //Add region button pressed
    $scope.insertRegion = function (region) {
        $http.post('../../services/region', {
            "regionName": region.regionName
        }).success(function (data) {
            getInfo();
        });
        $mdDialog.hide();
    };

    //Update region button pressed
    $scope.updateRegion = function (region) {
        $http.put('../../services/region/' + region.regionId, {
            "regionName": region.regionName
        }).success(function (data) {
            getInfo();
        });
        $mdDialog.hide();
    };
};